package com.example.week1

import java.io.Serializable

data class Team(
    val name: String,
    val stadium: String
) : Serializable