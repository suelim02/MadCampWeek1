package com.example.week1.ui.notifications

data class NotificationPost(
    val title: String // 리스트 항목에 표시될 텍스트
)
